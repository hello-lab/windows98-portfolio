1. encrypt the shown id
2. merge duplicates in css file
3. make animations on click